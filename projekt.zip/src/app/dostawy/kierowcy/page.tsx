"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

type Kierowca = {
  id: string;
  imie: string;
  telefon: string;
  aktywny: boolean;
};

export default function KierowcyPage() {
  const [kierowcy, setKierowcy] = useState<Kierowca[]>([]);
  const [imie, setImie] = useState("");
  const [telefon, setTelefon] = useState("");
  const [edytowanyId, setEdytowanyId] = useState<string | null>(null);
  const [pokazFormularz, setPokazFormularz] = useState(false);
  const [zapisywanie, setZapisywanie] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, "kierowcy"),
      orderBy("imie")
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const dane = snapshot.docs.map((dokument) => ({
          id: dokument.id,
          ...dokument.data(),
        })) as Kierowca[];

        setKierowcy(dane);
      },
      (error) => {
        console.error("Błąd pobierania kierowców:", error);
      }
    );

    return () => unsubscribe();
  }, []);

  function wyczyscFormularz() {
    setImie("");
    setTelefon("");
    setEdytowanyId(null);
  }

  function otworzDodawanie() {
    wyczyscFormularz();
    setPokazFormularz(true);
  }

  function rozpocznijEdycje(kierowca: Kierowca) {
    setImie(kierowca.imie);
    setTelefon(kierowca.telefon || "");
    setEdytowanyId(kierowca.id);
    setPokazFormularz(true);
  }

  function zamknijFormularz() {
    wyczyscFormularz();
    setPokazFormularz(false);
  }

  async function zapiszKierowce(
    e: FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    if (!imie.trim()) {
      alert("Podaj imię kierowcy.");
      return;
    }

    try {
      setZapisywanie(true);

      if (edytowanyId) {
        await updateDoc(
          doc(db, "kierowcy", edytowanyId),
          {
            imie: imie.trim(),
            telefon: telefon.trim(),
            zmieniono: serverTimestamp(),
          }
        );
      } else {
        await addDoc(collection(db, "kierowcy"), {
          imie: imie.trim(),
          telefon: telefon.trim(),
          aktywny: true,
          utworzono: serverTimestamp(),
        });
      }

      zamknijFormularz();
    } catch (error) {
      console.error(error);
      alert(
        "Nie udało się zapisać kierowcy. Sprawdź reguły Firestore."
      );
    } finally {
      setZapisywanie(false);
    }
  }

  async function zmienAktywnosc(
    kierowca: Kierowca
  ) {
    try {
      await updateDoc(
        doc(db, "kierowcy", kierowca.id),
        {
          aktywny: !kierowca.aktywny,
          zmieniono: serverTimestamp(),
        }
      );
    } catch (error) {
      console.error(error);
      alert("Nie udało się zmienić statusu kierowcy.");
    }
  }

  async function usunKierowce(
    kierowca: Kierowca
  ) {
    const potwierdzenie = window.confirm(
      `Czy na pewno chcesz usunąć kierowcę ${kierowca.imie}?`
    );

    if (!potwierdzenie) {
      return;
    }

    try {
      await deleteDoc(
        doc(db, "kierowcy", kierowca.id)
      );
    } catch (error) {
      console.error(error);
      alert("Nie udało się usunąć kierowcy.");
    }
  }

  return (
    <main className="min-h-screen bg-gray-100">
      {/* NAGŁÓWEK */}

      <header className="bg-yellow-400 shadow-sm">
        <div className="mx-auto flex max-w-6xl flex-col justify-between gap-4 px-5 py-5 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Jak u Mamy
            </h1>

            <p className="text-gray-700">
              Kierowcy
            </p>
          </div>

          <Link
            href="/dostawy"
            className="rounded-lg bg-gray-900 px-5 py-3 text-center font-bold text-white"
          >
            ← Panel dostaw
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-6xl p-5">
        {/* TYTUŁ */}

        <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              Kierowcy
            </h2>

            <p className="mt-1 text-gray-500">
              Zarządzaj kierowcami realizującymi dostawy.
            </p>
          </div>

          <button
            onClick={
              pokazFormularz
                ? zamknijFormularz
                : otworzDodawanie
            }
            className="rounded-lg bg-yellow-400 px-5 py-3 font-bold text-gray-900"
          >
            {pokazFormularz
              ? "✕ Zamknij"
              : "+ Dodaj kierowcę"}
          </button>
        </div>

        {/* FORMULARZ */}

        {pokazFormularz && (
          <form
            onSubmit={zapiszKierowce}
            className="mb-6 rounded-xl bg-white p-5 shadow-sm"
          >
            <h3 className="mb-5 text-xl font-bold text-gray-900">
              {edytowanyId
                ? "Edytuj kierowcę"
                : "Nowy kierowca"}
            </h3>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block font-semibold text-gray-700">
                  Imię
                </label>

                <input
                  type="text"
                  value={imie}
                  onChange={(e) =>
                    setImie(e.target.value)
                  }
                  placeholder="Np. Mateusz"
                  className="w-full rounded-lg border border-gray-300 p-3 text-gray-900"
                />
              </div>

              <div>
                <label className="mb-1 block font-semibold text-gray-700">
                  Telefon
                </label>

                <input
                  type="text"
                  value={telefon}
                  onChange={(e) =>
                    setTelefon(e.target.value)
                  }
                  placeholder="600 123 456"
                  className="w-full rounded-lg border border-gray-300 p-3 text-gray-900"
                />
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              <button
                type="submit"
                disabled={zapisywanie}
                className="rounded-lg bg-green-600 px-6 py-3 font-bold text-white disabled:opacity-50"
              >
                {zapisywanie
                  ? "Zapisywanie..."
                  : edytowanyId
                  ? "💾 Zapisz zmiany"
                  : "✓ Dodaj kierowcę"}
              </button>

              <button
                type="button"
                onClick={zamknijFormularz}
                className="rounded-lg bg-gray-200 px-6 py-3 font-bold text-gray-700"
              >
                Anuluj
              </button>
            </div>
          </form>
        )}

        {/* LISTA KIEROWCÓW */}

        <div className="space-y-3">
          {kierowcy.map((kierowca) => (
            <div
              key={kierowca.id}
              className={`rounded-xl bg-white p-5 shadow-sm ${
                !kierowca.aktywny
                  ? "opacity-60"
                  : ""
              }`}
            >
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xl font-bold text-gray-900">
                      🚗 {kierowca.imie}
                    </h3>

                    {kierowca.aktywny ? (
                      <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
                        AKTYWNY
                      </span>
                    ) : (
                      <span className="rounded-full bg-gray-200 px-3 py-1 text-xs font-bold text-gray-600">
                        NIEAKTYWNY
                      </span>
                    )}
                  </div>

                  {kierowca.telefon && (
                    <a
                      href={`tel:${kierowca.telefon.replace(
                        /\s/g,
                        ""
                      )}`}
                      className="mt-2 block text-gray-600"
                    >
                      📞 {kierowca.telefon}
                    </a>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() =>
                      rozpocznijEdycje(kierowca)
                    }
                    className="rounded-lg bg-blue-100 px-4 py-2 font-semibold text-blue-700"
                  >
                    ✏️ Edytuj
                  </button>

                  <button
                    onClick={() =>
                      zmienAktywnosc(kierowca)
                    }
                    className="rounded-lg bg-gray-200 px-4 py-2 font-semibold text-gray-700"
                  >
                    {kierowca.aktywny
                      ? "⏸ Wyłącz"
                      : "▶ Aktywuj"}
                  </button>

                  <button
                    onClick={() =>
                      usunKierowce(kierowca)
                    }
                    className="rounded-lg bg-red-100 px-4 py-2 font-semibold text-red-700"
                  >
                    🗑 Usuń
                  </button>
                </div>
              </div>
            </div>
          ))}

          {kierowcy.length === 0 && (
            <div className="rounded-xl bg-white p-10 text-center shadow-sm">
              <p className="text-lg font-bold text-gray-700">
                Brak kierowców
              </p>

              <p className="mt-1 text-gray-500">
                Dodaj pierwszego kierowcę.
              </p>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}